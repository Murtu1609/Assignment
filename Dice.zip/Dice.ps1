﻿#Requires -Modules @{ModuleName='AWS.Tools.Common';ModuleVersion='4.1.14.0'}
#Requires -Modules @{ModuleName='AWS.Tools.S3';ModuleVersion='4.1.14.0'}
Write-Host (ConvertTo-Json -InputObject $LambdaInput -Compress -Depth 5)

$NoOfDice = $LambdaInput.NoOfDice
$NoOfSides = $LambdaInput.NoOfSides
$NoOfRolls = $LambdaInput.NoOfRolls

$sum = @()


for($x=1;$x -le $NoOfRolls;$x=$x+1)
{
$total=0

for($i=1;$i -le $NoOfDice;$i=$i+1)
{

$result= Get-Random -Minimum 1 -Maximum $NoOfSides
$total = $total+$result
}
$sum = $sum + $total

}
$output = $sum | Group-Object -NoElement | Select-Object @{ n='SumOfDice:Count'; e={ '{0}:{1}' -f $_.Values[0], $_.Count } }
#$output = $sum | Group-Object
$filename = -join((65..90)+(97..122) | Get-Random -Count 15 | ForEach-Object{[char]$_})
$filename2 = -join((65..90)+(97..122) | Get-Random -Count 15 | ForEach-Object{[char]$_})

cd\
$output | ConvertTo-Json | Set-Content ".\tmp\$filename.json"
#$output | Set-Content ".\tmp\$filename.json"
Write-S3Object -BucketName diceresult -File ".\tmp\$filename.json"

$Summary = @{NoOfDice=$NoOfDice;NoOfSides=$NoOfSides;NoOfRolls=$NoOfRolls}
$Summary | ConvertTo-Json | Set-Content ".\tmp\$filename2.json"
#$Summary | Set-Content ".\tmp\$filename2.json"
Write-S3Object -BucketName dicesummary -File ".\tmp\$filename2.json"