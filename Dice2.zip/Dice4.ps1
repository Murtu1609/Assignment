
#Requires -Modules @{ModuleName='AWS.Tools.Common';ModuleVersion='4.1.14.0'}
#Requires -Modules @{ModuleName='AWS.Tools.S3';ModuleVersion='4.1.14.0'}
Write-Host (ConvertTo-Json -InputObject $LambdaInput -Compress -Depth 5)

$Bucket = "diceresult"
$Bucket2 = "dicesummary"

$resultfile = Get-S3Object -BucketName $Bucket
$resultfile2 = Get-S3Object -BucketName $Bucket2
$total = @()
$total2 = @()

cd\
foreach($object in $resultfile) {
 
    $path=$object.key
    Read-S3Object -BucketName $bucket -Key $object.Key -File ".\tmp\$path"
    $total +=  (Get-Content ".\tmp\$path" | ConvertFrom-Json)

   }

   foreach($object in $resultfile2) {
 
    $path=$object.key
    Read-S3Object -BucketName $Bucket2 -Key $object.Key -File ".\tmp\$path"
    $total2 +=  (Get-Content ".\tmp\$path" | ConvertFrom-Json)

   }

$total | ConvertTo-Json | Set-Content ".\tmp\TotalDiceResults.json"
$total2 | ConvertTo-Json | Set-Content ".\tmp\TotalDiceSummary.json"

Write-S3Object -BucketName dicefinal -File ".\tmp\TotalDiceResults.json"
Write-S3Object -BucketName dicefinal -File ".\tmp\TotalDiceSummary.json"
